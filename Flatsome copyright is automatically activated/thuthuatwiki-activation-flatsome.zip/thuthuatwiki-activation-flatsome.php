<?php
/**
 * Thuthuatwiki - Phạm Minh Khải - Kích hoạt Bản quyền Flatsome tự động.
 *
 * @package      Thuthuatwiki - Phạm Minh Khải
 * @link         https://thuthuatwiki.com/
 * @since        1.0
 *
 * @wordpress-plugin
 * Plugin Name:       Automated Flatsome Activation
 * Version:           1.0
 * Plugin URI:        https://thuthuatwiki.com/share-theme-flatsome-wordpress/
 * Description:       Khi cài đặt plugin sẽ tự động kích hoạt bản quyền Flatsome sau đó sẽ tự động hủy kích hoạt Plugin. Hãy xóa Plugin sau khi Kích hoạt.
 * Author:            Thuthuatwiki - Phạm Minh Khải
 * Author URI:        https://thuthuatwiki.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

defined('ABSPATH') || exit;

/**
 * Updater class.
 */
class Thuthuatwiki_Flatsome_Activation
{
	/**
	 * Admin notices.
	 */
	private $notices = array();
	public function __construct()
	{
		if (get_option('thuthuatwiki_notices') === false) {
			$this->thuthuatwiki_activated();
			return;
		}

		$this->notices = get_option('thuthuatwiki_notices', array());
		add_action('admin_notices', array($this, 'show_notices'));
	}
	/**
	 * Add admin notice.
	 */
	private function add_notice($message)
	{
		$this->notices[] = $message;
	}
	/**
	 * Show admin notices.
	 */
	public function show_notices()
	{
		if (empty($this->notices)) {
			return;
		}
		echo '<div class="notice notice-info is-dismissible thuthuatwiki-activation-flatsome-notice">';
		if (count($this->notices) == 1) { ?>
			<h2>Theme Flatsome trên Website: "
				<?php echo get_bloginfo('name'); ?>" của Bạn đã được Kích hoạt Bản Quyền
			</h2>
			<p>Một số đoạn code giúp bạn sử dụng website đơn giản và dễ dàng hơn:</p>
			<Xin>Bạn <a href="<?php echo get_site_url(); ?>/wp-admin/theme-editor.php?file=functions.php" target="_blank"
					rel="noopener noreferrer">nhấn vào đây để chuyển đến tệp Functions.php</a> Hãy nhấn vào Icon sẽ tự động sao chép
				nội dung đoạn code!</p>
				<table class="thuthuatwiki-copy">
					<tbody>
						<tr>
							<td>
								<p>Mã code này Tắt thông báo bản quyền Flatsome trong tương lai:</p>
								<div class="thuthuatwiki-copy-content">/* Xóa thông báo Bản Quyền Flatsome */
									delete_option( 'flatsome_wupdates');add_action( 'init', function () { remove_action(
									'admin_notices', 'flatsome_maintenance_admin_notice' ); } );</div>
							</td>
							<td>
								<p>Mã Code này Tắt Thông báo cáo các plugin tích hợp với Flatsome:</p>
								<div class="thuthuatwiki-copy-content">/* Tắt Notice Plugin tích hợp với Flatsome */
									add_action('init', function(){ remove_action( 'tgmpa_register',
									'flatsome_register_required_plugins' ); });</div>
							</td>

							<td>
								<p>Mã Code này Xóa các Size Hình ảnh mặc định của WordPress:</p>
								<div class="thuthuatwiki-copy-content">/* Xóa các Size hình ảnh mặc định của WordPress */
									function thuthuatwiki_remove_default_image_sizes( $sizes) { unset( $sizes['large']); unset(
									$sizes['thumbnail']); unset( $sizes['medium']); unset( $sizes['medium_large']); unset(
									$sizes['1536x1536']); unset( $sizes['2048x2048']); return $sizes; }
									add_filter('intermediate_image_sizes_advanced', 'thuthuatwiki_remove_default_image_sizes');
								</div>
							</td>
							<td>
								<p>Mã Code này loại bỏ tự động viết hoa trong WordPress:</p>
								<div class="thuthuatwiki-copy-content">/* Loại bỏ tự động viết hoa trong WordPress */
									$filters = array('the_content', 'the_title', 'wp_title', 'comment_text');
									foreach ($filters as $filter) {
									$priority = has_filter($filter, 'capital_P_dangit');
									if ($priority !== false) {
									remove_filter($filter, 'capital_P_dangit', $priority);
									}
									}</div>
							</td>
						</tr>
						<tr>
							<td>
								<p>Mã Code này Bật Classic Editor thay thế cho Gutenberg:</p>
								<div class="thuthuatwiki-copy-content">/* Bật Classic Editor */
									add_filter('use_block_editor_for_post', '__return_false');</div>
							</td>
							<td>
								<p>Mã Code này Bật Classic Widget thay thế cho Gutenberg:</p>
								<div class="thuthuatwiki-copy-content">/* Bật Classic Widget */
									add_filter( 'use_widgets_block_editor', '__return_false' );</div>
							</td>

							<td>
								<p>Mã Code này Tự động căn giữa Hình ảnh trong Edit Post / Page / Product:</p>
								<div class="thuthuatwiki-copy-content">/* Tự động Căn giữa hình ảnh Lớn nhất khi Đăng bài */
									function flatsome_image_size_center() { update_option('image_default_align', 'center' ); }
									add_action('after_setup_theme', 'flatsome_image_size_center');</div>
							</td>
							<td>
								<p>Mã Code này Tự động chọn Size ảnh Lớn nhất trong Edit Post / Page / Product:</p>
								<div class="thuthuatwiki-copy-content">/* Tự động chọn hình ảnh Lớn nhất khi Đăng bài */
									function flatsome_image_size_large() { update_option('image_default_size', 'large' ); }
									add_action('after_setup_theme', 'flatsome_image_size_large');</div>
							</td>
						</tr>
					</tbody>
				</table>
				<h3>Một vài tiện ích gợi ý cho bạn:</h3>
				<ul class="thuthuatwiki_list-plugins">

					<li>
						<p>Tạo Child-Theme Flatsome</p><a
							href="<?php echo get_site_url(); ?>/wp-admin/admin.php?page=flatsome-setup&step=customize"
							target="_blank">
							<div class="wp-menu-image dashicons-before dashicons-admin-plugins" aria-hidden="true"></div>Tạo
							Child-Theme mới
						</a>
					</li>
					<li>
						<p>Xóa các Theme không sử dụng</p><a href="<?php echo get_site_url(); ?>/wp-admin/themes.php"
							target="_blank">
							<div class="wp-menu-image dashicons-before dashicons-admin-plugins" aria-hidden="true"></div>Xóa các
							Theme không sử dụng
						</a>
					</li>
					<li>
						<p>Plugin đánh giá KK Star Rattings</p><a
							href="<?php echo get_site_url(); ?>/wp-admin/plugin-install.php?s=kk%2520star%2520ratings&tab=search&type=term"
							target="_blank">
							<div class="wp-menu-image dashicons-before dashicons-admin-plugins" aria-hidden="true"></div>Cài đặt
							Plugin KK Star Rattings
						</a>
					</li>
					<li>
						<p>Plugin Mục lục</p><a
							href="<?php echo get_site_url(); ?>/wp-admin/plugin-install.php?s=Table%2520Of%2520Contents&tab=search&type=term"
							target="_blank">
							<div class="wp-menu-image dashicons-before dashicons-admin-plugins" aria-hidden="true"></div>Cài đặt
							Plugin Table Of Contents
						</a>
					</li>
					<li>
						<p>Quan tâm đến tôi</p><a href="https://thuthuatwiki.com" target="_blank">
							<div class="wp-menu-image dashicons-before dashicons-admin-users" aria-hidden="true"></div>Xem thêm các
							bài viết mới nhất từ blog của Thuthuatwiki
						</a>
					</li>
				</ul>
				<h3><em>Chú ý !!!</em></h3>
				<p>Khi kích hoạt plugin thì theme Flatsome của bạn đã được tự động kích hoạt bản quyền và tự động huỷ kích hoạt
					plugin, bạn có thể sao chép các đoạn code được chia sẻ và sử dụng các tiện ích gợi ý bên trên, sau đó hãy xoá
					plugin này và nhấn F5 để reload lại trang.
				</p>
				<?php
		}
		foreach ($this->notices as $message) {
			echo '<p>' . $message . '</p>';
		}
		echo '</div>';
		update_option('thuthuatwiki_notices', array());
		deactivate_plugins(plugin_basename(__FILE__));
	}
	/**
	 * Save plugin data to DB.
	 */
	private function save_data()
	{
		update_option('thuthuatwiki_notices', $this->notices);
		add_option('flatsome_wup_purchase_code', 'GWrxBEss-VqSg-cJbs-dVvg-QzLEDfLzzExZ');
		add_option('flatsome_wup_supported_until', '14.07.2099');
		add_option('flatsome_wup_buyer', 'Licensed');
		add_option('flatsome_wup_sold_at', time());
		delete_option('flatsome_wup_errors');
		delete_option('flatsome_wupdates');
	}
	/**
	 * Run the Activate Process.
	 */
	private function thuthuatwiki_activated()
	{
		$this->suffix = '_' . substr(md5(microtime()), 0, 4);
		$this->add_notice('');
		$this->save_data();
	}
}
/**
 * Cleanup the database after the plugin is deactivated.
 */
function Thuthuatwiki_Flatsome_Activation_clean()
{
	delete_option('thuthuatwiki_notices');
}
register_deactivation_hook(__FILE__, 'Thuthuatwiki_Flatsome_Activation_clean');
/**
 * Initialize the plugin.
 */
$Thuthuatwiki_Flatsome_Activation = new Thuthuatwiki_Flatsome_Activation();
add_action('admin_head', function () { ?>
		<style>
			div.thuthuatwiki-copy-content {
				vertical-align: middle;
				text-align: center;
			}

			textarea.thuthuatwiki-copy-content {
				font-family: courier;
				vertical-align: middle;
				word-break: break-all;
				width: 55%;
				color: #999;
				background: #fff;
				border: none;
				font-size: 90%;
				padding: 0;
				border-radius: 0;
			}

			table.thuthuatwiki-copy {
				width: 100%;
			}

			button.thuthuatwiki-copy-content {
				background: unset;
				border: none;
				position: relative;
				top: -10px;
			}

			.dashicons-media-code:before {
				content: "\f13f" !important;
			}

			.dashicons-admin-plugins:before {
				content: "\f546" !important;
			}

			button.thuthuatwiki-copy-content .dashicons-media-code {
				font-size: 2.5rem;
				color: #ff686b;
			}

			.thuthuatwiki-activation-flatsome-notice a {
				text-decoration: none;
			}

			button.thuthuatwiki-copy-content:hover .dashicons-media-code {
				color: #05c494;
			}

			ul.thuthuatwiki_list-plugins {
				display: flex;
				flex-wrap: wrap;
				justify-content: space-around;
				align-items: center;
			}

			ul.thuthuatwiki_list-plugins li {
				max-width: 19%;
				flex-basis: 19%;
			}

			ul.thuthuatwiki_list-plugins a {
				display: flex;
				align-items: center;
				padding: 10px;
				background: #e5f8ff;
				min-height: 2rem;
				border-radius: 10px;
				font-size: 14px;
				color: black;
			}

			ul.thuthuatwiki_list-plugins img {
				width: 30px;
				height: 30px;
			}

			ul.thuthuatwiki_list-plugins li:hover a {
				background: #5482ff;
				color: #fff;
			}

			ul.thuthuatwiki_list-plugins .wp-menu-image {
				margin-right: 10px;
			}

			textarea.thuthuatwiki-copy-content::-webkit-scrollbar {
				display: none;
			}

			ul.thuthuatwiki_list-plugins .dashicons-before:before {
				color: #1d2327 !important;
			}

			.thuthuatwiki-copy-content {
				background: #ffeedd;
				padding: 10px;
				border-radius: 10px
			}

			table.thuthuatwiki-copy td p {
				min-height: 2.5rem;
				display: -webkit-box !important;
				-webkit-line-clamp: 2;
				-webkit-box-orient: vertical;
				overflow: hidden;
			}

			table.thuthuatwiki-copy td {
				text-align: center
			}
		</style>
		<script>
			jQuery(document).ready(function ($) { $("div.thuthuatwiki-copy-content").each(function () { var temp = $(this).html(); $(this).html(""); $(this).append("<textarea readonly class=\"thuthuatwiki-copy-content\">" + temp + "</textarea>"); $(this).append("<button class=\"thuthuatwiki-copy-content\"><span class='dashicons dashicons-media-code'></span></button>"); }); $('button.thuthuatwiki-copy-content').on('click', function (event) { $(this).prev().select(); document.execCommand('copy'); }); });
		</script>
		<?php
});